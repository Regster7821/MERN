import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <div id=''>
          <h1>Hello Dojo!</h1>
          <h2>Things I need to do:</h2>
          <ul>
            <li>Finish coding HW</li>
            <li>Make dinner</li>
            <li>Put up laundry</li>
            <li>Clean room</li>
          </ul>
        </div>  
      </header>
    </div>
  );
}

export default App;
