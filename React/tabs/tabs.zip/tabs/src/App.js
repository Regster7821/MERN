import React from 'react';
import './App.css';
import Component from './components/component'


function App() {
  return (
    <div className="App">
      <Component />
    </div>
  );
}

export default App;
