import React from 'react';
import './App.css';
import UserForm from './components/component';

function App() {
  return (
    <div className="App">
      <UserForm />
    </div>
  );
}

export default App;
