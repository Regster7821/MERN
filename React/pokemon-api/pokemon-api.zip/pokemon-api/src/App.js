import React from 'react';
import './App.css';
import Pokemon from './components/first-component'

function App() {
  return (
    <div className="App">
      <Pokemon />
    </div>
  );
}

export default App;
