class User{
    constructor(name, email){
        this.name = name;
        this.email = email;
        this.account = new BankAccount(this.name, 0.02, 0);
    }
    makeDeposit(amount){
        this.account.deposit(amount);
        return this;
    }
    makeWithdrawal(amount){
        this.account.withdraw(amount);
        return this;
    }
    displayBalance(){
        this.account.displayBalance();
        return this;
    }
    displayAccountInfo(){
        this.account.displayInfo();
        return this;
    }
    makeTransfer(amount, name){
        this.account.balance -= amount;
        name.account.balance += amount;
        return this;
    }
}

class BankAccount {
    constructor(name, intRate, balance) {
        this.name = name;
        this.intRate = intRate;
        this.balance = balance;
    }
    deposit(amount) {
        this.balance += amount;
        return this;
    }
    withdraw(amount) {
        this.balance -= amount;
        return this;
    }
    displayInfo() {
        console.log('User:', this.name, '- Interest Rate:', this.intRate, '- Balance:',this.balance);
        return this;
    }
    displayBalance(){
        console.log('User:', this.name, '-',`Balance:`, this.balance);
    }
    yieldInterest() {
        this.balance += (this.balance * this.intRate);
        return this;
    }
}

const reagan = new User('Reagan Crosby', 'johnreagancrosby@gmail.com');
const elon = new User('Elon Musk', 'emusk@gmail.com');

reagan.makeDeposit(100).displayBalance();
elon.displayBalance();

console.log('After account transfer...');

reagan.makeTransfer(100, elon).displayBalance();
elon.displayBalance();